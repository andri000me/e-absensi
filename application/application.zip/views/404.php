<!--banner-->	
<div class="banner">
	<h2><a href="./">Home</a><i class="fa fa-angle-right"></i><span>Eror 404</span></h2>
</div>
<div class="blank">
	<div class="blank-page">
		<div class='alert bg-danger' role='alert'>
		<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
		Mohon maaf! Halaman/konten yang anda akses tidak ditemukan. Terimkasih.
		</div>
	</div>
</div>